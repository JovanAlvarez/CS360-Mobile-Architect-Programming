package com.example.weighttracker_jovanalvarez;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class GoalActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int userId;

    private EditText editGoalWeight;
    private EditText editPhoneNumber;
    private Button buttonSaveGoal;
    private Button buttonEnableSms;
    private TextView textPermissionStatus;

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_goal);

        dbHelper = new DatabaseHelper(this);

        userId = getIntent().getIntExtra("USER_ID", -1);

        editGoalWeight = findViewById(R.id.editGoalWeight);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonSaveGoal = findViewById(R.id.buttonSaveGoal);
        buttonEnableSms = findViewById(R.id.buttonEnableSms);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);

        updatePermissionStatus();

        // Preload saved phone number if it exists
        String savedPhone = dbHelper.getPhoneNumber(userId);
        if (!savedPhone.isEmpty()) {
            editPhoneNumber.setText(savedPhone);
        }

        buttonSaveGoal.setOnClickListener(v -> {
            String goalText = editGoalWeight.getText().toString().trim();
            String phoneText = editPhoneNumber.getText().toString().trim();

            if (goalText.isEmpty()) {
                Toast.makeText(this, "Enter a goal weight.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double goalWeight = Double.parseDouble(goalText);

                boolean goalSaved = dbHelper.saveGoalWeight(userId, goalWeight);
                boolean phoneSaved = true;

                if (!phoneText.isEmpty()) {
                    phoneSaved = dbHelper.savePhoneNumber(userId, phoneText);
                }

                if (goalSaved && phoneSaved) {
                    Toast.makeText(this, "Goal and phone settings saved.", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Failed to save settings.", Toast.LENGTH_SHORT).show();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter a valid number.", Toast.LENGTH_SHORT).show();
            }
        });

        buttonEnableSms.setOnClickListener(v -> requestSmsPermission());
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );

        } else {
            Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            textPermissionStatus.setText("Permission Status: Granted");
        } else {
            textPermissionStatus.setText("Permission Status: Not Granted");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
            updatePermissionStatus();
        }
    }
}