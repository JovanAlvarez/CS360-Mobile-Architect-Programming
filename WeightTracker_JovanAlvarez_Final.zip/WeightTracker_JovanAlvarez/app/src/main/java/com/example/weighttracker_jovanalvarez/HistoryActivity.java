package com.example.weighttracker_jovanalvarez;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int userId;

    private EditText editEntryId;
    private EditText editDate;
    private EditText editWeight;
    private EditText editNote;

    private Button buttonAddHistoryEntry;
    private Button buttonUpdateEntry;
    private Button buttonDeleteEntry;
    private Button buttonRefreshHistory;

    private TextView textHistoryOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_history);

        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);

        editEntryId = findViewById(R.id.editEntryId);
        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        editNote = findViewById(R.id.editNote);

        buttonAddHistoryEntry = findViewById(R.id.buttonAddHistoryEntry);
        buttonUpdateEntry = findViewById(R.id.buttonUpdateEntry);
        buttonDeleteEntry = findViewById(R.id.buttonDeleteEntry);
        buttonRefreshHistory = findViewById(R.id.buttonRefreshHistory);

        textHistoryOutput = findViewById(R.id.textHistoryOutput);

        if (editDate.getText().toString().trim().isEmpty()) {
            String today = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
            editDate.setText(today);
        }

        refreshHistory();

        buttonAddHistoryEntry.setOnClickListener(v -> addEntry());
        buttonUpdateEntry.setOnClickListener(v -> updateEntry());
        buttonDeleteEntry.setOnClickListener(v -> deleteEntry());
        buttonRefreshHistory.setOnClickListener(v -> refreshHistory());
    }

    private void addEntry() {
        String date = editDate.getText().toString().trim();
        String weightText = editWeight.getText().toString().trim();
        String note = editNote.getText().toString().trim();

        if (date.isEmpty() || weightText.isEmpty()) {
            Toast.makeText(this, "Enter both date and weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double weight = Double.parseDouble(weightText);
            boolean success = dbHelper.addWeight(userId, weight, date, note);

            if (success) {
                Toast.makeText(this, "Entry added.", Toast.LENGTH_SHORT).show();
                clearFields(false);
                refreshHistory();
            } else {
                Toast.makeText(this, "Failed to add entry.", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter a valid weight.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateEntry() {
        String entryIdText = editEntryId.getText().toString().trim();
        String date = editDate.getText().toString().trim();
        String weightText = editWeight.getText().toString().trim();
        String note = editNote.getText().toString().trim();

        if (entryIdText.isEmpty() || date.isEmpty() || weightText.isEmpty()) {
            Toast.makeText(this, "Enter entry ID, date, and weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int entryId = Integer.parseInt(entryIdText);
            double weight = Double.parseDouble(weightText);

            boolean success = dbHelper.updateWeightEntry(entryId, userId, date, weight, note);

            if (success) {
                Toast.makeText(this, "Entry updated.", Toast.LENGTH_SHORT).show();
                clearFields(true);
                refreshHistory();
            } else {
                Toast.makeText(this, "No matching entry found.", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter valid numeric values.", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteEntry() {
        String entryIdText = editEntryId.getText().toString().trim();

        if (entryIdText.isEmpty()) {
            Toast.makeText(this, "Enter an entry ID to delete.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int entryId = Integer.parseInt(entryIdText);

            boolean success = dbHelper.deleteWeightEntry(entryId, userId);

            if (success) {
                Toast.makeText(this, "Entry deleted.", Toast.LENGTH_SHORT).show();
                clearFields(true);
                refreshHistory();
            } else {
                Toast.makeText(this, "No matching entry found.", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter a valid entry ID.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshHistory() {
        textHistoryOutput.setText(dbHelper.getAllWeightsForUser(userId));
    }

    private void clearFields(boolean clearId) {
        if (clearId) {
            editEntryId.setText("");
        }
        editWeight.setText("");
        editNote.setText("");
    }
}