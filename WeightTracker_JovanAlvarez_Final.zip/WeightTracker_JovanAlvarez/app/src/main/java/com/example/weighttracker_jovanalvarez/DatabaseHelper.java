package com.example.weighttracker_jovanalvarez;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 4;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";
    public static final String COL_PHONE = "phone";

    // Weights table
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COL_WEIGHT_ID = "id";
    public static final String COL_WEIGHT_VALUE = "weight";
    public static final String COL_DATE = "date";
    public static final String COL_USER_REF = "user_id";
    public static final String COL_NOTE = "note";

    // Goals table
    public static final String TABLE_GOALS = "goals";
    public static final String COL_GOAL_ID = "id";
    public static final String COL_GOAL_WEIGHT = "goal_weight";
    public static final String COL_GOAL_USER_REF = "user_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE, "
                + COL_PASSWORD + " TEXT, "
                + COL_PHONE + " TEXT)";

        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " ("
                + COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_WEIGHT_VALUE + " REAL, "
                + COL_DATE + " TEXT, "
                + COL_NOTE + " TEXT, "
                + COL_USER_REF + " INTEGER)";

        String createGoalsTable = "CREATE TABLE " + TABLE_GOALS + " ("
                + COL_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_GOAL_WEIGHT + " REAL, "
                + COL_GOAL_USER_REF + " INTEGER)";

        db.execSQL(createUsersTable);
        db.execSQL(createWeightsTable);
        db.execSQL(createGoalsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        onCreate(db);
    }

    // Create a new user account
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        if (userExists(username)) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Check whether a username already exists
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + " = ?",
                new String[]{username}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Validate login credentials
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS
                        + " WHERE " + COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?",
                new String[]{username, password}
        );

        boolean valid = cursor.getCount() > 0;
        cursor.close();
        return valid;
    }

    // Get user ID from username
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + COL_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + " = ?",
                new String[]{username}
        );

        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }

        cursor.close();
        return userId;
    }
    public boolean addWeight(int userId, double weight, String date, String note) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_VALUE, weight);
        values.put(COL_DATE, date);
        values.put(COL_NOTE, note);
        values.put(COL_USER_REF, userId);

        long result = db.insert(TABLE_WEIGHTS, null, values);
        return result != -1;
    }
    // Get the latest weight entry for a user
    public String getLatestWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COL_WEIGHT_VALUE + ", " + COL_DATE +
                        " FROM " + TABLE_WEIGHTS +
                        " WHERE " + COL_USER_REF + " = ?" +
                        " ORDER BY " + COL_WEIGHT_ID + " DESC LIMIT 1",
                new String[]{String.valueOf(userId)}
        );

        String latestWeight = "No entries yet";

        if (cursor.moveToFirst()) {
            double weight = cursor.getDouble(0);
            String date = cursor.getString(1);
            latestWeight = "Latest Entry: " + weight + " lbs on " + date;
        }

        cursor.close();
        return latestWeight;
    }

    // Save or update a goal weight for a user
    public boolean saveGoalWeight(int userId, double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COL_GOAL_ID + " FROM " + TABLE_GOALS +
                        " WHERE " + COL_GOAL_USER_REF + " = ?",
                new String[]{String.valueOf(userId)}
        );

        ContentValues values = new ContentValues();
        values.put(COL_GOAL_WEIGHT, goalWeight);
        values.put(COL_GOAL_USER_REF, userId);

        long result;

        if (cursor.moveToFirst()) {
            int goalId = cursor.getInt(0);
            result = db.update(
                    TABLE_GOALS,
                    values,
                    COL_GOAL_ID + " = ?",
                    new String[]{String.valueOf(goalId)}
            );
        } else {
            result = db.insert(TABLE_GOALS, null, values);
        }

        cursor.close();
        return result != -1;
    }

    // Get a user's goal weight
    public String getGoalWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COL_GOAL_WEIGHT +
                        " FROM " + TABLE_GOALS +
                        " WHERE " + COL_GOAL_USER_REF + " = ?",
                new String[]{String.valueOf(userId)}
        );

        String goalText = "Goal Weight: Not set";

        if (cursor.moveToFirst()) {
            double goalWeight = cursor.getDouble(0);
            goalText = "Goal Weight: " + goalWeight + " lbs";
        }

        cursor.close();
        return goalText;
    }
    // Get all weight entries for a user as a formatted string
    public String getAllWeightsForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COL_WEIGHT_ID + ", " + COL_DATE + ", " + COL_WEIGHT_VALUE + ", " + COL_NOTE +
                        " FROM " + TABLE_WEIGHTS +
                        " WHERE " + COL_USER_REF + " = ?" +
                        " ORDER BY " + COL_WEIGHT_ID + " DESC",
                new String[]{String.valueOf(userId)}
        );

        StringBuilder builder = new StringBuilder();

        if (cursor.getCount() == 0) {
            builder.append("No weight entries found.");
        } else {
            builder.append("ID   Date         Weight   Note\n");
            builder.append("------------------------------------------\n");

            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                double weight = cursor.getDouble(2);
                String note = cursor.getString(3);

                builder.append(id)
                        .append("   ")
                        .append(date)
                        .append("   ")
                        .append(weight)
                        .append(" lbs   ")
                        .append(note == null ? "" : note)
                        .append("\n");
            }
        }

        cursor.close();
        return builder.toString();
    }

    // Update an entry by its ID
    public boolean updateWeightEntry(int entryId, int userId, String date, double weight, String note) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_DATE, date);
        values.put(COL_WEIGHT_VALUE, weight);
        values.put(COL_NOTE, note);

        int rowsAffected = db.update(
                TABLE_WEIGHTS,
                values,
                COL_WEIGHT_ID + " = ? AND " + COL_USER_REF + " = ?",
                new String[]{String.valueOf(entryId), String.valueOf(userId)}
        );

        return rowsAffected > 0;
    }

    // Delete an entry by its ID
    public boolean deleteWeightEntry(int entryId, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_WEIGHTS,
                COL_WEIGHT_ID + " = ? AND " + COL_USER_REF + " = ?",
                new String[]{String.valueOf(entryId), String.valueOf(userId)}
        );

        return rowsDeleted > 0;
    }
    // Save or update a user's phone number
    public boolean savePhoneNumber(int userId, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_PHONE, phoneNumber);

        int rowsAffected = db.update(
                TABLE_USERS,
                values,
                COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)}
        );

        return rowsAffected > 0;
    }

    // Get a user's phone number
    public String getPhoneNumber(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COL_PHONE + " FROM " + TABLE_USERS +
                        " WHERE " + COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)}
        );

        String phoneNumber = "";

        if (cursor.moveToFirst()) {
            phoneNumber = cursor.getString(0);
            if (phoneNumber == null) {
                phoneNumber = "";
            }
        }

        cursor.close();
        return phoneNumber;
    }

    // Get numeric goal weight for SMS comparison
    public double getGoalWeightValue(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COL_GOAL_WEIGHT +
                        " FROM " + TABLE_GOALS +
                        " WHERE " + COL_GOAL_USER_REF + " = ?",
                new String[]{String.valueOf(userId)}
        );

        double goalWeight = -1;

        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(0);
        }

        cursor.close();
        return goalWeight;
    }
}