package com.example.weighttracker_jovanalvarez;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int userId;
    private String username;

    private TextView textWelcome;
    private TextView textGoalSummary;
    private TextView textLatestWeight;

    private Button buttonAddEntry;
    private Button buttonViewHistory;
    private Button buttonSetGoal;
    private Button buttonSmsSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);

        dbHelper = new DatabaseHelper(this);

        userId = getIntent().getIntExtra("USER_ID", -1);
        username = getIntent().getStringExtra("USERNAME");

        textWelcome = findViewById(R.id.textWelcome);
        textGoalSummary = findViewById(R.id.textGoalSummary);
        textLatestWeight = findViewById(R.id.textLatestWeight);

        buttonAddEntry = findViewById(R.id.buttonAddEntry);
        buttonViewHistory = findViewById(R.id.buttonViewHistory);
        buttonSetGoal = findViewById(R.id.buttonSetGoal);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        if (username != null && !username.isEmpty()) {
            textWelcome.setText("Welcome back, " + username);
        }

        refreshDashboard();

        buttonAddEntry.setOnClickListener(v -> showAddWeightDialog());

        buttonSetGoal.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, GoalActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        buttonViewHistory.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, HistoryActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        buttonSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, GoalActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDashboard();
    }

    private void refreshDashboard() {
        textGoalSummary.setText(dbHelper.getGoalWeight(userId));
        textLatestWeight.setText(dbHelper.getLatestWeight(userId));
    }

    private void showAddWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Weight Entry");

        final EditText input = new EditText(this);
        input.setHint("Enter weight in lbs");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String weightText = input.getText().toString().trim();

            if (weightText.isEmpty()) {
                Toast.makeText(this, "Please enter a weight.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double weight = Double.parseDouble(weightText);
                String currentDate = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
                        .format(new Date());

                boolean saved = dbHelper.addWeight(userId, weight, currentDate, "");

                if (saved) {
                    Toast.makeText(this, "Weight entry saved.", Toast.LENGTH_SHORT).show();
                    refreshDashboard();
                    checkGoalAndSendSms(weight);
                } else {
                    Toast.makeText(this, "Failed to save weight entry.", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
    private void checkGoalAndSendSms(double currentWeight) {
        double goalWeight = dbHelper.getGoalWeightValue(userId);
        String phoneNumber = dbHelper.getPhoneNumber(userId);

        if (goalWeight == -1) {
            return; // no goal saved
        }

        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            return; // no phone number saved
        }

        if (currentWeight <= goalWeight) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    String message = "Congratulations! You've reached your goal weight of " + goalWeight + " lbs.";
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    Toast.makeText(this, "Goal reached! SMS alert sent.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Goal reached, but SMS permission is not granted.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}